import React from 'react';

interface DeveloperNavProps {
  currentPath?: string;
}

export default function DeveloperNav({ currentPath }: DeveloperNavProps) {
  return null;
}