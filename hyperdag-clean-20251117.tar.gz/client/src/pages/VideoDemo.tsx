import React from 'react';
import VideoDemo from '@/components/VideoDemo';

const VideoDemoPage: React.FC = () => {
  return <VideoDemo />;
};

export default VideoDemoPage;