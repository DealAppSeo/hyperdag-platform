import { SupabaseSBTDemo } from "@/components/supabase-sbt-demo";

export default function SupabaseDemoPage() {
  return <SupabaseSBTDemo />;
}